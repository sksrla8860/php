<? 
	header("Content-Type: text/html; charset=UTF-8");
	
	echo("<h1>Hello PHP</h1>");
	echo("<h1>안녕하세요. PHP</h1>");
?>

