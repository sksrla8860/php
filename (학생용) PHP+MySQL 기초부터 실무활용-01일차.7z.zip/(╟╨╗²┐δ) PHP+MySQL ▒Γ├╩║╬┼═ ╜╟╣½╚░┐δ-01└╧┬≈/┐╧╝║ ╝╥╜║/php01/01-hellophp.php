<? 
	header("Content-Type: text/html; charset=UTF-8");
	
	echo("Hello PHP");
	echo("안녕하세요. PHP");
?>


