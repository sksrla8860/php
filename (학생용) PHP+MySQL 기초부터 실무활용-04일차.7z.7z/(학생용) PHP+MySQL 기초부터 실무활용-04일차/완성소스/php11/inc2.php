<?
    echo("<hr />");
    $num++;
    echo("<h1>num=".$num."</h1>");
    echo("<hr />");
?>
